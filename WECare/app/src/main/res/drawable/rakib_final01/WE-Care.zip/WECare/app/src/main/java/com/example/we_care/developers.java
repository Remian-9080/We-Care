package com.example.we_care;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class developers extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_developers);
    }
}