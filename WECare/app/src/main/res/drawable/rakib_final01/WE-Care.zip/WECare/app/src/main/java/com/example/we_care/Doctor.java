package com.example.we_care;

public class Doctor {
    String name;

    public Doctor(String name) {
        this.name = name;
    }

    public Doctor(){

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
