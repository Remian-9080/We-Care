package com.example.we_care;

public class School {
    String name;

    public School(){

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public School(String name) {
        this.name = name;
    }
}
